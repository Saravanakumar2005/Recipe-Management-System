import React, { useState } from "react";
import logo from "./images/logo.png";
import cap from "./images/cap.png";

const Signup = () => {
  const [message, setMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Basic validation
    if (formData.password !== formData.confirmPassword) {
      setMessage("Passwords do not match!");
      return;
    }

    // If passwords match
    setMessage("Signup Successful!");
    // Here you would typically send the data to your backend
  };

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "linear-gradient(to bottom, #FFCC99, #FFFFFF)",
        padding: "20px",
        boxSizing: "border-box",
        overflow: "auto",
      }}
    >
      {/* Page Wrapper */}
      <div style={{ width: "100%", maxWidth: "1200px" }}>
        {/* Navigation Bar */}
        <nav
          style={{
            width: "100%",
            backgroundColor: "white",
            padding: "5px",
            display: "flex",
            alignItems: "center",
            boxShadow: "0px 2px 5px rgba(0, 0, 0, 0.1)",
            position: "fixed",
            top: 0,
            left: 0,
            height: "50px",
            zIndex: 1000,
          }}
        >
          {/* Logo Section */}
          <div style={{ display: "flex", alignItems: "center" }}>
            <img
              src={logo}
              alt="Foody App Logo"
              style={{ height: "40px", width: "auto", marginRight: "10px" }}
            />
            <span
              style={{
                fontSize: "24px",
                fontWeight: "bold",
                color: "orange",
                fontFamily: '"Times New Roman", serif',
              }}
            >
              Maran Parotta Kadaai
            </span>
          </div>
        </nav>

        <div
          style={{
            marginTop: "80px",
            width: "100%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <img
            src={cap}
            alt="Cap Image"
            style={{
              width: "80px",
              height: "auto",
              marginBottom: "-25px",
            }}
          />
          <div
            style={{
              backgroundColor: "white",
              padding: "20px",
              borderRadius: "12px",
              boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.1)",
              width: "300px",
              textAlign: "center",
              marginTop: "10px",
            }}
          >
            <h2 style={{ color: "#333", marginBottom: "10px", fontSize: "20px" }}>Sign Up</h2>

            {message && <p style={{ color: message.includes("Successful") ? "green" : "red", fontSize: "14px" }}>{message}</p>}

            {/* Signup Form */}
            <form onSubmit={handleSubmit}>
              {/* Full Name Field */}
              <label
                style={{
                  display: "block",
                  marginTop: "8px",
                  fontWeight: "bold",
                  textAlign: "left",
                  color: "#ff6600",
                  fontSize: "14px",
                }}
              >
                Full Name:
              </label>
              <input
                type="text"
                name="name"
                required
                value={formData.name}
                onChange={handleChange}
                style={{
                  width: "90%",
                  padding: "8px",
                  marginTop: "4px",
                  border: "1px solid #ccc",
                  borderRadius: "5px",
                  backgroundColor: "white",
                  color: "black",
                  fontSize: "14px",
                }}
              />

              {/* Email Field */}
              <label
                style={{
                  display: "block",
                  marginTop: "8px",
                  fontWeight: "bold",
                  textAlign: "left",
                  color: "#ff6600",
                  fontSize: "14px",
                }}
              >
                Email:
              </label>
              <input
                type="email"
                name="email"
                required
                value={formData.email}
                onChange={handleChange}
                style={{
                  width: "90%",
                  padding: "8px",
                  marginTop: "4px",
                  border: "1px solid #ccc",
                  borderRadius: "5px",
                  backgroundColor: "white",
                  color: "black",
                  fontSize: "14px",
                }}
              />

              {/* Phone Number Field */}
              <label
                style={{
                  display: "block",
                  marginTop: "8px",
                  fontWeight: "bold",
                  textAlign: "left",
                  color: "#ff6600",
                  fontSize: "14px",
                }}
              >
                Phone Number:
              </label>
              <input
                type="tel"
                name="phone"
                required
                value={formData.phone}
                onChange={handleChange}
                style={{
                  width: "90%",
                  padding: "8px",
                  marginTop: "4px",
                  border: "1px solid #ccc",
                  borderRadius: "5px",
                  backgroundColor: "white",
                  color: "black",
                  fontSize: "14px",
                }}
              />

              {/* Password Field */}
              <label
                style={{
                  display: "block",
                  marginTop: "8px",
                  fontWeight: "bold",
                  textAlign: "left",
                  color: "#ff6600",
                  fontSize: "14px",
                }}
              >
                Password:
              </label>
              <div
                style={{
                  width: "90%",
                  position: "relative",
                  margin: "0 auto",
                }}
              >
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  style={{
                    width: "100%",
                    padding: "8px",
                    marginTop: "5px",
                    border: "1px solid #ccc",
                    borderRadius: "5px",
                    backgroundColor: "white",
                    color: "black",
                    fontSize: "14px",
                  }}
                />
                {/* Eye Icon for Password Toggle */}
                <span
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: "absolute",
                    right: "-10px",
                    top: "50%",
                    transform: "translateY(-40%)",
                    cursor: "pointer",
                    color: "black", 
                    fontSize: "14px", 
                  }}
                >
                  {showPassword ? "👁️" : "👁️‍🗨️"}
                </span>
              </div>

              {/* Confirm Password Field */}
              <label
                style={{
                  display: "block",
                  marginTop: "8px",
                  fontWeight: "bold",
                  textAlign: "left",
                  color: "#ff6600",
                  fontSize: "14px",
                }}
              >
                Confirm Password:
              </label>
              <input
                type="password"
                name="confirmPassword"
                required
                value={formData.confirmPassword}
                onChange={handleChange}
                style={{
                  width: "90%",
                  padding: "8px",
                  marginTop: "4px",
                  border: "1px solid #ccc",
                  borderRadius: "5px",
                  backgroundColor: "white",
                  color: "black",
                  fontSize: "14px",
                }}
              />

              {/* Signup Button */}
              <button
                type="submit"
                style={{
                  marginTop: "15px",
                  padding: "10px",
                  width: "90%",
                  backgroundColor: "#ff6600",
                  color: "white",
                  border: "none",
                  borderRadius: "5px",
                  fontSize: "16px",
                  cursor: "pointer",
                  transition: "0.3s ease",
                }}
                onMouseOver={(e) =>
                  (e.target.style.backgroundColor = "#cc5200")
                }
                onMouseOut={(e) =>
                  (e.target.style.backgroundColor = "#ff6600")
                }
              >
                Sign Up
              </button>
            </form>

            {/* Login Link */}
            <p
              style={{
                marginTop: "15px",
                textAlign: "center",
                fontWeight: "bold",
                color: "#333",
                fontSize: "14px",
              }}
            >
              Already have an account?
              <a
                href="login"
                style={{
                  color: "#ff6600",
                  textDecoration: "none",
                  fontWeight: "bold",
                  display: "block",
                  marginTop: "5px",
                  fontSize: "14px",
                }}
                onMouseOver={(e) =>
                  (e.target.style.textDecoration = "underline")
                }
                onMouseOut={(e) =>
                  (e.target.style.textDecoration = "none")
                }
              >
                Login here
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;