package com.RecipemanagementSystem.RecipeManagementSystem.Service.impf;
import com.RecipemanagementSystem.RecipeManagementSystem.Entity.User;
import com.RecipemanagementSystem.RecipeManagementSystem.Repo.UserRepo;
import com.RecipemanagementSystem.RecipeManagementSystem.payload.response.LoginMessage;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.*;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional
    public String addUser(User newUser) {
        // Check if username already exists
        if (userRepo.findByUserName(newUser.getUser_name()).isPresent()) {
            return "Username already taken!";
        }

        // Encrypt password before saving
        newUser.setPassword(passwordEncoder.encode(newUser.getPassword()));
        userRepo.save(newUser);
        return "User registered successfully: " + newUser.getUser_name();
    }

    @Transactional
    public LoginMessage loginUser(String email, String password) {
        User existingUser = userRepo.findByEmail(email);

        if (existingUser == null) {
            return new LoginMessage("Email does not exist", false);
        }

        boolean isPasswordMatch = passwordEncoder.matches(password, existingUser.getPassword());

        if (!isPasswordMatch) {
            return new LoginMessage("Incorrect password", false);
        }

        return new LoginMessage("Login Successful", true);
    }
}
