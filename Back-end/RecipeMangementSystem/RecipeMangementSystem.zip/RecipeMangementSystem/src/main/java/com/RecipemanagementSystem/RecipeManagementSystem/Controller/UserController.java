package com.RecipemanagementSystem.RecipeManagementSystem.Controller;

import com.RecipemanagementSystem.RecipeManagementSystem.Entity.User;
import com.RecipemanagementSystem.RecipeManagementSystem.Service.impf.UserService;
import com.RecipemanagementSystem.RecipeManagementSystem.payload.response.LoginMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("api/v1/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public ResponseEntity<String> Welcome() {
        return ResponseEntity.ok("Welcome to Recipe Management System ");
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User newUser) {
        String result = userService.addUser(newUser);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }


    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User user) {
        LoginMessage loginResponse = userService.loginUser(user.getEmail(), user.getPassword());

        if (loginResponse.getStatus()) {
            return ResponseEntity.ok(loginResponse);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(loginResponse);
        }
    }


}
